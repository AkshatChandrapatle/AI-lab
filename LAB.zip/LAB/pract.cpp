#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;

class Node{
public:
    vector<int> initial;
    Node* parent;
    vector<Node*> children;

    Node(vector<int> _initial,Node* _parent){
        initial = _initial;
        parent=_parent;
    }

    int findZero(){
        for(int i=0;i<this->initial.size();i++){
            if(this->initial[i]==0){
                return i;
            }
        }
        return -1;
    }

    void moveUp(){

    }
    void moveDown(){

    }
    void moveRight(){

    }
    void moveLeft(){

    }
    

};

class Puzzle{
public:

};

int main(){

    return 0;
}