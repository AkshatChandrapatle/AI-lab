#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
#include <unordered_set>

using namespace std;

// Hash function for vector<int> to use with unordered_set
struct VectorHash {
    size_t operator()(const vector<int>& v) const {
        size_t seed = v.size();
        for (auto& i : v) {
            seed ^= i + 0x9e3779b9 + (seed << 6) + (seed >> 2);
        }
        return seed;
    }
};

class Node {
public:
    vector<Node *> children;
    vector<int> initialVector;
    Node *parent;
    int g; // Cost from start to current node
    int h; // Heuristic cost to goal

    Node(vector<int> _initialVector, Node *_parent, int _g, int _h)
        : initialVector(_initialVector), parent(_parent), g(_g), h(_h) {}

    void printPuzzle(vector<int> vectorValues) {
        int count = 0;
        for (auto i : vectorValues) {
            if (count % 3 == 0)
                cout << "\n";
            cout << i << ' ';
            count++;
        }
        cout << "\n";
    }

    int findZero() {
        return distance(this->initialVector.begin(), find(this->initialVector.begin(), this->initialVector.end(), 0));
    }

    void moveUp(int& nodesCount) {
        int zPos = this->findZero();
        vector<int> temp = this->initialVector;
        if (zPos >= 3) {
            swap(temp[zPos], temp[zPos - 3]);
            int newG = g + 1;
            int newH = calculateHeuristic(temp);
            Node *child = new Node(temp, this, newG, newH);
            children.push_back(child);
            nodesCount++;
        }
    }

    void moveDown(int& nodesCount) {
        int zPos = this->findZero();
        vector<int> temp = this->initialVector;
        if (zPos < 6) {
            swap(temp[zPos], temp[zPos + 3]);
            int newG = g + 1;
            int newH = calculateHeuristic(temp);
            Node *child = new Node(temp, this, newG, newH);
            children.push_back(child);
            nodesCount++;
        }
    }

    void moveRight(int& nodesCount) {
        int zPos = this->findZero();
        vector<int> temp = this->initialVector;
        if (zPos % 3 < 2) {
            swap(temp[zPos], temp[zPos + 1]);
            int newG = g + 1;
            int newH = calculateHeuristic(temp);
            Node *child = new Node(temp, this, newG, newH);
            children.push_back(child);
            nodesCount++;
        }
    }

    void moveLeft(int& nodesCount) {
        int zPos = this->findZero();
        vector<int> temp = this->initialVector;
        if (zPos % 3 > 0) {
            swap(temp[zPos], temp[zPos - 1]);
            int newG = g + 1;
            int newH = calculateHeuristic(temp);
            Node *child = new Node(temp, this, newG, newH);
            children.push_back(child);
            nodesCount++;
        }
    }

    // Calculate the Manhattan distance heuristic
    static int calculateHeuristic(const vector<int>& state) {
        int h = 0;
        for (int i = 0; i < state.size(); ++i) {
            if (state[i] == 0) continue;
            int targetX = (state[i] - 1) / 3;
            int targetY = (state[i] - 1) % 3;
            int currentX = i / 3;
            int currentY = i % 3;
            h += abs(targetX - currentX) + abs(targetY - currentY);
        }
        return h;
    }

    int f() const {
        return g + h;
    }
};

// Comparator for the priority queue to order by f = g + h
struct CompareNode {
    bool operator()(Node* const& n1, Node* const& n2) {
        return n1->f() > n2->f();
    }
};

void traceSolution(Node* goalNode) {
    vector<Node *> sol;
    Node *curr = goalNode;
    sol.push_back(goalNode);
    while (curr->parent != nullptr) {
        curr = curr->parent;
        sol.push_back(curr);
    }
    reverse(sol.begin(), sol.end());
    int depth = 0;
    for (auto i : sol) {
        depth += 1;
        i->printPuzzle(i->initialVector);
        cout << "\n";
    }
    cout << "Depth: " << depth - 1 << endl;
}

class Puzzle {
private:
    priority_queue<Node *, vector<Node *>, CompareNode> openSet;
    unordered_set<vector<int>, VectorHash> closedSet;
    vector<int> finalVector;
    int nodesCount;

public:
    Puzzle(vector<int> _initialVector, vector<int> _finalVector)
        : nodesCount(0) {
        Node *initialNode = new Node(_initialVector, nullptr, 0, Node::calculateHeuristic(_initialVector));
        this->openSet.push(initialNode);
        this->finalVector = _finalVector;
        nodesCount++;
    }

    void AStar() {
        cout << "Searching for solution..." << endl;
        while (!openSet.empty()) {
            Node *currentNode = openSet.top();
            openSet.pop();
            closedSet.insert(currentNode->initialVector);

            if (currentNode->initialVector == finalVector) {
                cout << "Solution found :)" << endl;
                traceSolution(currentNode);
                cout << "Nodes count: " << nodesCount << endl;
                return;
            }

            currentNode->moveRight(nodesCount);
            currentNode->moveUp(nodesCount);
            currentNode->moveLeft(nodesCount);
            currentNode->moveDown(nodesCount);

            for (auto &child : currentNode->children) {
                if (closedSet.find(child->initialVector) == closedSet.end()) {
                    openSet.push(child);
                }
            }
        }
        cout << "No solution found :(" << endl;
    }
};

int main() {
  vector<int> initialVector = {7,1,2,4,8,3,0,5,6};
    vector<int> finalVector = {1, 2, 3, 4, 5, 6, 7, 8, 0};

    Puzzle puzzle(initialVector, finalVector);
    puzzle.AStar();

    return 0;
}
