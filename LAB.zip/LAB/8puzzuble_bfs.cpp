#include <iostream>
#include <algorithm>
#include <vector>
#include <queue>
using namespace std;

class Node
{
public:
  vector<Node *> children;
  vector<int> initialVector;
  Node *parent;

  Node(vector<int> _initialVector, Node *_parent)
  {
    initialVector = _initialVector;
    parent = _parent;
  }

  void printPuzzle(vector<int> vectorValues)
  {
    int count = 0;
    for (auto i : vectorValues)
    {
      if (count % 3 == 0)
        cout << "\n";

      cout << i << ' ';
      count++;
    }
  }

  int findZero()
  {
    // Find index of zero in vector
    vector<int>::iterator it = find(this->initialVector.begin(), this->initialVector.end(), 0);
    return static_cast<int>(distance(this->initialVector.begin(), it));
  }

  void moveUp()
  {
    int zPos = this->findZero();
    vector<int> temp = this->initialVector;

    if (zPos >= 3)
    {
      swap(temp[zPos], temp[zPos - 3]);
      Node *child = new Node(temp, this);
      children.push_back(child);
    }
  }

  void moveDown()
  {
    int zPos = this->findZero();
    vector<int> temp = this->initialVector;

    if (zPos < 6)
    {
      swap(temp[zPos], temp[zPos + 3]);
      Node *child = new Node(temp, this);
      children.push_back(child);
    }
  }

  void moveRight()
  {
    int zPos = this->findZero();
    vector<int> temp = this->initialVector;

    if (zPos % 3 < 2)
    {
      swap(temp[zPos], temp[zPos + 1]);
      Node *child = new Node(temp, this);
      children.push_back(child);
    }
  }

  void moveLeft()
  {
    int zPos = this->findZero();
    vector<int> temp = this->initialVector;

    if (zPos % 3 > 0)
    {
      swap(temp[zPos], temp[zPos - 1]);
      Node *child = new Node(temp, this);
      children.push_back(child);
    }
  }
};
///////
bool isVisited(queue<Node *> queue, Node *currentNode)
{
  bool exist = false;

  while (!queue.empty())
  {
    if (queue.front()->initialVector == currentNode->initialVector)
    {
      exist = true;
    }

    queue.pop();
  }

  return exist;
}

void traceSolution(vector<Node *> sol, Node *g)
{
  Node *curr = g;
  sol.push_back(g);

  while (curr->parent != nullptr)
  {
    curr = curr->parent;
    sol.push_back(curr);
  }

  reverse(sol.begin(), sol.end());

  int depth = 0;
  for (auto i : sol)
  {
    depth += 1;
    i->printPuzzle(i->initialVector);
    cout << "\n";
  }

  cout << "Depth: " << depth - 1 << endl;
}

class Puzzle
{
private:
  std::queue<Node *> queue;
  std::queue<Node *> visited;
  vector<int> finalVector;
  int nodesCount;

public:
  Puzzle(vector<int> _initialVector, vector<int> _finalVector)
  {
    Node *initialNode = new Node(_initialVector, nullptr);
    this->queue.push(initialNode);

    this->finalVector = _finalVector;
    this->nodesCount = 1;
  }

  void BFS(vector<int> initialVector)
  {
    vector<Node *> solution;

    cout << "Searching for solution..." << endl;

    while (!queue.empty())
    {
      Node *currentNode = this->queue.front();

      this->visited.push(currentNode);
      this->queue.pop();

      currentNode->moveRight();
      currentNode->moveUp();
      currentNode->moveLeft();
      currentNode->moveDown();

      this->nodesCount++;

      for (auto currentChild : currentNode->children)
      {

        // If currentChild is equal to finalVector retunr void
        if (currentChild->initialVector == this->finalVector)
        {
          cout << "Solution found :)" << endl;

          traceSolution(solution, currentChild);
          cout << "Nodes count: " << this->nodesCount << endl;
          return;
        }

        if (!isVisited(this->queue, currentChild) && !isVisited(this->visited, currentChild))
        {
          this->queue.push(currentChild);
        }
      }
    }
  }
};

int main()
{
  // vector<int> initialVector = {
  //     1, 2, 3,
  //     0, 4, 6,
  //     7, 5, 8};

  // vector<int> finalVector = {
  //     1, 2, 3,
  //     4, 5, 0,
  //     6, 7, 8};
  vector<int> initialVector = {7,1,2,4,8,3,0,5,6};
    vector<int> finalVector = {1, 2, 3, 4, 5, 6, 7, 8, 0};

  Puzzle puzzle(initialVector, finalVector);

  puzzle.BFS(initialVector);

  return 0;
}