#include <iostream>
#include <vector>
#include <algorithm>


int minFilesToChange(std::vector<int>& fileSize, std::vector<int>& minSize) {
    int n = fileSize.size();
    int totalBytes = 0;
    for (int i = 0; i < n; ++i) {
        totalBytes += fileSize[i];
    }

    std::vector<int> diffs(n);
    for (int i = 0; i < n; ++i) {
        diffs[i] = fileSize[i] - minSize[i];
    }

    std::sort(diffs.rbegin(), diffs.rend());

    int filesChanged = 0;
    for (int i = 0; i < n && totalBytes < n * accumulate(minSize.begin(), minSize.end(), 0); ++i) {
        totalBytes -= diffs[i];
        ++filesChanged;
    }

    return totalBytes >= n * accumulate(minSize.begin(), minSize.end(), 0) ? filesChanged : -1;
}

int main() {
    std::vector<int> fileSize = {4, 1, 5, 2, 3};
    std::vector<int> minSize = {3, 2, 2, 1, 4};
    std::cout << minFilesToChange(fileSize, minSize) << std::endl; // Output: 3
    return 0;
}