% Facts
male(baburao) .
male(surendra) .
male(subhash) .
male(satish) .
male(rahul) .
male(kiran) .
male(sanjay) .
male(ayush) .
male(pratik) .
male(vivan) .
male(pransh) .
male(sarthak) .
female(shalan) .
female(lata) .
female(jyoti) .
female(swati) .
female(deepali) .
female(shital) .
female(pradnya) .
female(rutuja) .
female(sam) .
female(prisha) .
female(jagruti) .

wife(gulabbai,baburao) .
wife(surekha,subhash) .
wife(shalan,sitaram) .
wife(lata,sanjay) .
wife(vandana,surendra).
wife(archana,satish) .
wife(tejal,kiran) .
wife(madhura,rahul) .
wife(shital,roshan) .

parent(baburao,subhash) .
parent(baburao,shalan) .
parent(baburao,lata) .
parent(baburao,surendra) .
parent(baburao,satish) .

parent(subhash,rahul) .
parent(subhash,swati) .
parent(subhash,jyoti) .
parent(sitaram,kiran) .
parent(sitaram,deepali).
parent(sanjay,shital) .
parent(surendra,ayush) .
parent(surendra,pradnya) .
parent(satish,pratik) .
parent(satish,rutuja) .
parent(kiran,sarthak) .
parent(kiran,jagruti) .
parent(rahul,sam) .
parent(rahul,vivan) .
parent(roshan,pransh) .
parent(roshan,prisha) .
parent(gulabbai,shalan).
parent(gulabbai,subhash).
parent(gulabbai,lata).
parent(gulabbai,surendra).
parent(gulabbai,satish).
parent(surekha,rahul).
parent(surenkha,jyoti).
parent(surekha,swati).
parent(vandana,ayush).
parent(vandana,pradnya).
parent(shalan,deepali).
parent(shalan,kiran).
parent(archana,pratik).
parent(archana,rutuja).
parent(tejal,sarthak).
parent(tejal,jagruti).
parent(madhura,vivan).
parent(madhura,sam).
parent(shital,pransh).
parent(shital,prisha).
parent(lata,shital).
husband(X,Y) :- wife(Y,X) .


% Rules:
brother(X,Y) :- parent(Z,X) , parent(Z,Y) , male(X).
sister(X,Y) :- parent(Z,X) , parent(Z,Y) , female(X).

%Rules:
father(X,Y) :- parent(X,Y) , male(X).
mother(X,Y) :- parent(X,Y) , female(X).

%Rules:
son(X,Y) :- parent(Y,X), male(X).
daughter(X,Y):- parent(Y,X), female(Y).

%Rules:
grandfather(X,Y) :- parent(X,Z) , parent(Z,Y), male(X).
grandmother(X,Y) :- parent(X,Z) , parent(Z,Y), female(X).

%Rules:
uncle(X,Y) :- brother(X,Z),parent(Z,Y);brotherinlaw(X,Z),parent(Z,Y) .
aunty(X,Y) :- uncle(Z,Y),wife(X,Z); sisterinlaw(X,Z),parent(Z,Y).

%Rules:
sibling(X,Y) :- parent(Z,X), parent(Z,Y),X \= Y.
cousin(X,Y) :- sibling(U,V),parent(U,X) , parent(V,Y).

%Rules:
nephew(X,Y) :- sibling(W,Y) , parent(W,X), male(X).
niece(X,Y) :- sibling(W,Y) , parent(W,X), female(X).

%Rules:
brotherinlaw(X,Y) :- wife(T,Y) , brother(X,T) ; husband(T,Y),brother(X,T).
sisterinlaw(X,Y) :- wife(T,Y) , sister(T,X) ; husband(T,Y),sister(X,T).

%Rules:
grandson(X,Y) :- parent(Z,X), parent(Y,Z) , male(X).
granddaughter(X,Y) :-  parent(Z,X), parent(Y,Z) , female(X).

%Rules:
great_grandfather(X,Y) :- parent(Z,Y) , grandfather(X,Z).
great_grandmother(X,Y) :- parent(Z,Y) , grandmother(X,Z).

%Rules:
great_uncle(X,Y) :-  uncle(X,Z),parent(Z,Y).
great_aunty(X,Y) :- aunty(X,Z),parent(Z,Y).

%Rules:
second_uncle(X,Y) :- cousin(V,X), parent(V,Y), male(X).
second_aunty(X,Y) :- cousin(V,X), parent(V,Y), female(X).

%Rules:
second_nephew(X,Y) :- cousin(W,Y), parent(W,X), male(X).
second_niece(X,Y) :- cousin(W,Y), parent(W,X), female(X).

%Rules:
second_cousin(X,Y) :- cousin(W,V),parent(W,X),parent(V,Y).


%relationship finnding

find_relationship(X,Y) :-
    husband(X,Y),write(X), write( " is husband of ") , write(Y), nl.

find_relationship(X,Y) :-
    wife(X,Y),write(X), write( " is wife of ") , write(Y), nl.

find_relationship(X,Y) :-
    son(X,Y),write(X), write( " is son of ") , write(Y), nl.

find_relationship(X,Y) :-
    daughter(X,Y),write(X), write( " is daughter of ") , write(Y), nl.

find_relationship(X,Y) :-
    grandfather(X,Y),write(X), write( " is grandfather of ") , write(Y), nl.

find_relationship(X,Y) :-
    grandmother(X,Y),write(X), write( " is grandmother of ") , write(Y), nl.

find_relationship(X,Y) :-
    granddaughter(X,Y),write(X), write( " is grand daughter of ") , write(Y), nl.

find_relationship(X,Y) :-
    grandson(X,Y),write(X), write( " is grand son of ") , write(Y), nl.

find_relationship(X,Y) :-
    great_grandfather(X,Y),write(X), write( " is great grand father of ") , write(Y), nl.

find_relationship(X,Y) :-
    great_grandmother(X,Y),write(X), write( " is great grand mother of ") , write(Y), nl.

find_relationship(X,Y) :-
    mother(X,Y),write(X), write( " is mother of ") , write(Y), nl.

find_relationship(X,Y) :-
    father(X,Y),write(X), write( " is father of ") , write(Y), nl.

find_relationship(X,Y) :-
    uncle(X,Y),write(X), write( " is uncle of ") , write(Y), nl.

find_relationship(X,Y) :-
    aunty(X,Y),write(X), write( " is aunty of ") , write(Y), nl.

find_relationship(X,Y) :-
    cousin(X,Y),write(X), write( " is cousin of ") , write(Y), nl.

find_relationship(X,Y) :-
    sisterinlaw(X,Y),write(X), write( " is sisterinlaw of ") , write(Y), nl.

find_relationship(X,Y) :-
    brotherinlaw(X,Y),write(X), write( " is brother in law of ") , write(Y), nl.

find_relationship(X,Y) :-
    great_uncle(X,Y),write(X), write( " is great uncle of ") , write(Y), nl.

find_relationship(X,Y) :-
    great_aunty(X,Y),write(X), write( " is great aunty of ") , write(Y), nl.

find_relationship(X,Y) :-
    nephew(X,Y),write(X), write( " is nephew of ") , write(Y), nl.


find_relationship(X,Y) :-
    niece(X,Y),write(X), write( " is niece of ") , write(Y), nl.


find_relationship(X,Y) :-
    second_aunty(X,Y),write(X), write( " is second aunty of ") , write(Y), nl.


find_relationship(X,Y) :-
    second_uncle(X,Y),write(X), write( " is second uncle of ") , write(Y), nl.


find_relationship(X,Y) :-
    second_nephew(X,Y),write(X), write( " is second nephew of ") , write(Y), nl.

find_relationship(X,Y) :-
    second_niece(X,Y),write(X), write( " is second niece of ") , write(Y), nl.

find_relationship(X,Y) :-
    second_cousin(X,Y),write(X), write( " is second cousin") , write(Y), nl.


find_relationship(X,Y) :-
    brother(X,Y),write(X), write( " is brother of ") , write(Y), nl.


find_relationship(X,Y) :-
    sister(X,Y),write(X), write( " is sister of ") , write(Y), nl.

find_relationship(X, Y) :- write('Relationship not defined between '), write(X), write(' and '), write(Y), nl.
