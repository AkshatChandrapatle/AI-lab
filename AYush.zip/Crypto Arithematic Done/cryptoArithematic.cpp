#include<iostream>
#include<vector>
using namespace std;
vector<int> visited(10,0);
struct node{
    char c;
    int v;
};

int isValid(int n, node nodelist[],string s1,string s2,string s3){
    int a=0,b=0,c=0;

    for(int i=0; i<s1.size(); i++){
        char temp = s1[i];
        for (int j = 0; j < n; j++)
        {
            if(nodelist[j].c==temp){
                 a = a*10+nodelist[j].v;
            }
        }
    }
    for(int i=0; i<s2.size(); i++){
        char temp = s2[i];
        for (int j = 0; j < n; j++)
        {
            if(nodelist[j].c==temp){
                 b = b*10+nodelist[j].v;
            }
        }
    }
    for(int i=0; i<s3.size(); i++){
        char temp = s3[i];
        for (int j = 0; j < n; j++)
        {
            if(nodelist[j].c==temp){
                 c = c*10+nodelist[j].v;
            }
        }
    }
    if(a+b==c) return 1;
    return 0;
}
int solve(int n, node nodelist[],string s1,string s2,string s3, int m){
    if(m==n){
        if(isValid(n,nodelist,s1,s2,s3)){
            for(int i=0; i<n;i++){
                cout<<nodelist[i].c<<"="<<nodelist[i].v<<endl;
            }
            return 1;
        }
    }
    for (int i = 0; i < 10; i++)
    {
        if(!visited[i]){
            visited[i] = 1;
            nodelist[m].v=i;
            if(solve(n,nodelist,s1,s2,s3,m+1)) return true;
            visited[i]=0;
        }
    }
    return false;
}

int main(){
    string s1 = "bwse";
    string s2 = "nall";
    string s3 = "gaves";
    vector<int> fre(26,0);
    for(char c:s1) fre[c-'a']++;
    for(char c:s2) fre[c-'a']++;
    for(char c:s3) fre[c-'a']++;
    int n=0;
    
    node nodelist[n];
    for(int i=0,j=0; i<26; i++){
        
        if(fre[i]){ 
            nodelist[j].c=i+'a';
            j++;
        }
        n=j;
    }
    if(!solve(n,nodelist,s1,s2,s3,0)) cout<<"No Solution";
    return  0;
}