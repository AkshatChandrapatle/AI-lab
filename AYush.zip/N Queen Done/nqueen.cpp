#include<iostream> 
using namespace std;
#include<vector>

void print(vector<vector<int>>v){
    int n=v.size();
    for(int i=0; i<n; i++){
        for(int j=0; j<n; j++){
            cout<<v[i][j]<<" ";
        }
        cout<<endl;
    }
}
bool isSafe(vector<vector<int>> &v, int row,int col){
    int n=v.size();
    for (int i = 0; i < col; i++)
    {
        if(v[row][i]) return false;
    }
    for (int i = row, j=col; i>=0 && j>=0; i--,j--)
    {
        if(v[i][j]) return false;
    }
    for (int i = row, j=col; i<n&& j>=0; i++ ,j--)
    {
        if(v[i][j]) return false;
    }
    return true;
}
bool solve(vector<vector<int>> &v, int col){
    int n=v.size();

    if(col>=n){ return true;}

    for(int i=0; i<n; i++){

        if(isSafe(v,i,col)){

            v[i][col] = 1;

            if(solve(v, col+1)) return true;
            
            v[i][col] =0;
        }
    }
    return false;
}
int main(){
    int n=2;
    vector<vector<int>> v(n,vector<int>(n,0));
    
    if(solve(v,0)) cout<< "Solution"<<endl ,print(v);
    else cout<<"Solution does not exist";
    
    return 0;
}