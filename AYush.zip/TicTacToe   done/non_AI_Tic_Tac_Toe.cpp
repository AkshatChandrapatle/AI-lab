#include<iostream>
using namespace std;

int board[9] = {2,2,2,2,2,2,2,2,2};
int win[8][3] = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{1,4,7},{2,5,8},{0,4,8},{2,4,6}};

void printBoard(){
    cout<<"Current Board Position: \n";
    string ele;
    cout<<"-------------\n";
    for(int i=0; i<9; i++){
        if(board[i]==2) ele = "   ";
        if(board[i]==3) ele = " X ";
        if(board[i]==5) ele = " O ";
        cout<<"|"<<ele;
        if((i+1)%3==0) cout<<"|"<<'\n'<<"-------------\n";
    }
}
int winner(int x){
    for(int i=0; i<8; i++){
        int c=0;
        for(int j=0; j<3; j++){
            if(board[win[i][j]] == x) c++;
        }
        if (c==3) return 1;
    }
    return 0;
}
int winPoss(int x){
    for(int i=0; i<8; i++){
        int c=0;
        int idx=-1;
        for(int j=0; j<3; j++){
            if(board[win[i][j]] == x) c++;
            else if (board[win[i][j]]==2) idx = win[i][j];
            else c--;
        }
        if (c==2) return idx;
    }
    return -1;
}
int make(int x){
    int idx;
    for(int i=0; i<9; i++){
        if(board[i]==2){
            idx=i;
            board[i]=x;
            if(winPoss(x)!=-1) return i;
            board[i] = 2;
        }
    }
    return idx;
}
void go(int x){
    int temp = winPoss(x);
    if(temp != -1){
        board[temp]=x;
        return;
    }
    temp = winPoss(3);
    if (temp != -1){
        board[temp]=x;
        return;
    }else{
    temp = make(x);
    board[temp] = x;
    }
}
int main(){
    int flag=1;
    for(int i=0; i<=8; i++){
        if(flag){
            cout<<"Player Turn \n Enter Position: ";
            int position;
            cin>>position;
            if(board[position]==2) board[position] = 3;
            else {
                cout<<"Entered position is already marked\n";
                i--;
                continue;
            }
            printBoard();
            if(winner(3)){
                cout<<"-------<< You Won >>------\n";
                printBoard();
                return 0;
            }
        }else{
            cout<<"Computer Turn: \n";
            go(5);
            if(winner(5)){
                cout<<"-------<< Comp Won >>------\n";
                printBoard();
                return 0;
            }
            printBoard();
        }
        cout<<flag;
        flag = 1-flag;
        cout<<flag;
    }

    return 0;
}