#include <iostream>
#include <vector>
#include <stack>
#include <map>
#include <set>

using namespace std;

int solve(int cont1, int cont2, int target) {
    stack<pair<int, int>> st;
    map<pair<int, int>, pair<int, int>> mp;
    set<pair<int, int>> visited;

    mp[make_pair(0, 0)] = make_pair(-1, -1);
    st.push(make_pair(0, 0));
    visited.insert(make_pair(0, 0));

    while (!st.empty()) {
        pair<int, int> temp = st.top();
        st.pop();
        
        int x = temp.first;
        int y = temp.second;
        
        if (x == target || y == target) {
            int t1 = x, t2 = y;
            cout << endl;
            while (mp[make_pair(t1, t2)].first != -1) {
                cout << "(" << t1 << "," << t2 << ") ";
                pair<int, int> prev = mp[make_pair(t1, t2)];
                t1 = prev.first;
                t2 = prev.second;
            }
            cout << "(0,0)" << endl;
            return 1;
        }

        // Generate all possible states
        vector<pair<int, int>> nextStates = {
            make_pair(cont1, y),  // Fill cont1
            make_pair(x, cont2),  // Fill cont2
            make_pair(0, y),      // Empty cont1
            make_pair(x, 0),      // Empty cont2
            make_pair(x + min(y, cont1 - x), y - min(y, cont1 - x)),  // Pour from cont2 to cont1
            make_pair(x - min(x, cont2 - y), y + min(x, cont2 - y))   // Pour from cont1 to cont2
        };

        for (auto& state : nextStates) {
            if (visited.find(state) == visited.end()) {
                visited.insert(state);
                st.push(state);
                mp[state] = temp;
            }
        }
    }
    return 0;
}

int main() {
    int cont1 = 4, cont2 = 3;
    int target = 2;
    if (!solve(cont1, cont2, target)) {
        cout << "No solution found." << endl;
    }
    return 0;
}
