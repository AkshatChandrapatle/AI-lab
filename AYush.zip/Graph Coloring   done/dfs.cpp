#include<iostream>
#include<vector>
using namespace std;

int isSafe(vector<vector<int>> graph, vector<int> color, int v, int c){
    for(int i=0; i<graph.size(); i++){
        if(graph[v][i] && color[i]==c){
            return 0;
        }
    }
    return 1;
}
int solve(int v, vector<vector<int>> graph, vector<int> color, int m){
    int V=graph.size();
    if(v==V){
        for (int i = 0; i < v; i++)
        {
            cout<<color[i]<<" ";
        }
        return 1;
    }
    for (int i = 1; i <= m; i++)
    {
        if(isSafe(graph,color,v,i)){
            color[v] = i;
            if(solve(v+1,graph,color,m)) return 1;
            color[v] = 0;
        }
    }
    
    return 0;
}
int main(){
    vector<vector<int>> graph ={{0,1,1,1,1,0,0,0},
                                {1,0,0,1,0,0,0,1},
                                {1,0,0,1,0,1,0,1},
                                {1,1,1,0,1,0,1,0},
                                {1,0,0,1,0,1,0,0},
                                {0,0,1,0,1,0,0,0},
                                {0,0,0,1,0,0,0,1},
                                {0,1,1,0,0,0,1,0}};
    int m=4;
    vector<int> color(graph.size(),0);
    if(!solve(0,graph,color,m)) cout<<"No Solution";
    return 0;
}